package com.rj.dao;

public interface DaoUser {
	public boolean AdminLogin(String username,String password);//����Ա��¼
}
